
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import HomeForm from './Components/HomeForm';
import TransactionForm from './Components/TransactionForm';
import Home from './Components/Home';


function App() {
  return (
    <div>
       
       <BrowserRouter>
       <Routes>
          <Route path='/' element={<Home/>}>Home</Route>
          <Route path='/signup' element={<HomeForm/>}></Route>
          <Route path='/transaction' element={<TransactionForm/>}></Route>
       </Routes>
       </BrowserRouter>
    </div>
  );
}

export default App;
