import React from 'react';
import Navbar from './CustomNavbar';
import backgroundImage from './Assets/jalal.jpg';

const Home = () => {
  return (
    <div style={{ 
      backgroundImage: `url(${backgroundImage})`, 
      backgroundSize: 'cover', 
      backgroundRepeat: 'no-repeat', 
     
      minHeight: '100vh' 
    }}>
      <Navbar />
      {/* Your other content here */}
    </div>
  );
};

export default Home;
