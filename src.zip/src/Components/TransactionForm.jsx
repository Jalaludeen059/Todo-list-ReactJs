import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';

function TransactionForm() {
  const [transactionType, setTransactionType] = useState('');
  const [amount, setAmount] = useState('');
  const [recipient, setRecipient] = useState('');
  const [date, setDate] = useState('');
  const [note, setNote] = useState('');
  const [validated, setValidated] = useState(false);

  const handleSubmit = (event) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }

    setValidated(true);
  };

  return (
    <Form
      noValidate
      validated={validated}
      onSubmit={handleSubmit}
      style={{
        backgroundColor: 'blue',
        color: 'white',
        padding: '20px',
        borderRadius: '10px',
        width: '300px',
        margin: 'auto',
      }}
    >
      <Form.Group controlId="transactionType" style={{ textAlign: 'center' }}>
        <Form.Label>Transaction Type</Form.Label>
        <Form.Control
          as="select"
          value={transactionType}
          onChange={(e) => setTransactionType(e.target.value)}
          required
          style={{ width: '100%', height: '30px', marginBottom: '10px' }}
        >
          <option value="">Select transaction type</option>
          <option value="credit">Credit</option>
          <option value="debit">Debit</option>
        </Form.Control>
        <Form.Control.Feedback type="invalid">
          Please select a transaction type.
        </Form.Control.Feedback>
      </Form.Group>

      <Form.Group controlId="amount" style={{ textAlign: 'center' }}>
        <Form.Label>Amount</Form.Label>
        <Form.Control
          type="number"
          placeholder="Enter amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          required
          style={{ width: '100%', height: '30px', marginBottom: '10px' }}
        />
        <Form.Control.Feedback type="invalid">
          Please provide the amount.
        </Form.Control.Feedback>
      </Form.Group>

      <Form.Group controlId="recipient" style={{ textAlign: 'center' }}>
        <Form.Label>Recipient</Form.Label>
        <Form.Control
          type="text"
          placeholder="Enter recipient"
          value={recipient}
          onChange={(e) => setRecipient(e.target.value)}
          required
          style={{ width: '100%', height: '30px', marginBottom: '10px' }}
        />
        <Form.Control.Feedback type="invalid">
          Please provide the recipient.
        </Form.Control.Feedback>
      </Form.Group>

      <Form.Group controlId="date" style={{ textAlign: 'center' }}>
        <Form.Label>Date</Form.Label>
        <Form.Control
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          required
          style={{ width: '100%', height: '30px', marginBottom: '10px' }}
        />
        <Form.Control.Feedback type="invalid">
          Please provide the date.
        </Form.Control.Feedback>
      </Form.Group>

      <Form.Group controlId="note" style={{ textAlign: 'center' }}>
        <Form.Label>Note</Form.Label>
        <Form.Control
          as="textarea"
          rows={3}
          placeholder="Enter note"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          style={{ width: '100%', marginBottom: '10px' }}
        />
      </Form.Group>

      <Button type="submit">Submit</Button>
    </Form>
  );
}

export default TransactionForm;
